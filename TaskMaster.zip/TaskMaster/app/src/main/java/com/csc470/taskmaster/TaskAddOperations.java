package com.csc470.taskmaster;

/**
 * Created by Joe Barrett on 12/1/2017.
 */


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;



public class TaskAddOperations extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_add_operations);
    }
}