package com.example.stephen.taskmaster;

/**
 * Created by Stephen on 10/20/2017.
 */

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.util.Log;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/**
 * Created by resortrat on 11/1/15.
 */
public class TaskHandler extends SQLiteOpenHelper {

    private static final String DATABASE_PATH = "/data/data/com.example.stephen.taskmanager/databases/"; //have to adjust

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "Tasks";

    public static final String TABLE_NAME = "items";

    public static final String COLUMN_ID = "_itemID";

    public static final String COLUMN_NAME ="_itemName";

    public static final String COLUMN_DONE = "_itemDone";

    public SQLiteDatabase dbSqlite;

    private final Context myContext;



    public TaskHandler(Context context) {
        super (context, DATABASE_NAME, null, DATABASE_VERSION);
        this.myContext = context;
    }

    @Override
    public void onCreate (SQLiteDatabase db) {

    }
    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void createDatabase() throws IOException {
        createDB();

    }





    private void createDB() {

        boolean dbExist = DBExists();

        if (!dbExist) {

            //By calling this method we create an empty database into the default
            //We need this so we can overwrite that database with our database

            this.getReadableDatabase();

            //now we copy the database we included!
            copyDBFromResource();
        }
    }
    //Determines if the Database has already been created;
    //If no database then creates into the program
    //If does exist, tells program to ignore creating the database
    private boolean DBExists() {

        SQLiteDatabase db = null;

        try {
            String databasePath = DATABASE_PATH + DATABASE_NAME;
            db = SQLiteDatabase.openDatabase(databasePath, null, SQLiteDatabase.OPEN_READWRITE);
            db.setLocale(Locale.getDefault());
            db.setLockingEnabled(true);
            db.setVersion(1);
        } catch (SQLiteException e) {

            Log.e("SqlHelper", "database not found");
        }

        if (db != null) {

            db.close();
        }

        return db != null;
    }

    //Takes the raw data from the database stored in the program and
    // converts into data readable by JAVA
    private void copyDBFromResource() {

        InputStream inputStream = null;
        OutputStream outStream = null;
        String dbFilePath = DATABASE_PATH + DATABASE_NAME;

        try {

            inputStream = myContext.getAssets().open(DATABASE_NAME);

            outStream = new FileOutputStream(dbFilePath);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outStream.write(buffer, 0, length);
            }

            outStream.flush();
            outStream.close();
            inputStream.close();

        } catch (IOException e) {

            throw new Error("Problem copying database from resource file.");
        }
    }

    //Function to connect the program to the database
    public void openDataBase() throws SQLException {

        String myPath = DATABASE_PATH + DATABASE_NAME;
        dbSqlite = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    @Override
    public synchronized void close() {

        if (dbSqlite != null)
        {
            dbSqlite.close();;
        }
        super.close();

    }

    //Returns cursor variable of stored data from the database
    public Cursor getCursor(int flag, String cs) {

        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();

        queryBuilder.setTables(TABLE_NAME);

        String[] asColumnsToReturn = new String[] { COLUMN_ID, COLUMN_NAME, COLUMN_DONE};
        Cursor mCursor = null;
        if(flag ==0)
            mCursor = queryBuilder.query(dbSqlite, asColumnsToReturn, null, null, null, null, "_itemName");
        else
            mCursor  = dbSqlite.rawQuery("SELECT * FROM items WHERE _itemName LIKE ? ", new String[] {"%"+cs+"%"});
        return mCursor;
    }

    //Uses a cursor to return the "_itemName" column of a selected item
    public String getName(Cursor c) {
        return(c.getString(1));
    }

    //Uses custom class "Location" and the "_id" of the database to return all data that matches
    //the primary key of an item in the database
    public Task getData(int id)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[] { COLUMN_ID, COLUMN_NAME, COLUMN_DONE}, COLUMN_ID + "=?", new String[]{ String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        assert cursor != null;
        Task data = new Task(cursor.getInt(0), cursor.getString(1), cursor.getInt(2));

        db.close();
        cursor.close();
        return data;
    }





}

