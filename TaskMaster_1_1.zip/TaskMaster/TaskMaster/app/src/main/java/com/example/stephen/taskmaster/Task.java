package com.example.stephen.taskmaster;

import java.io.Serializable;

/**
 * Created by Stephen on 10/20/2017.
 */

public class Task implements Serializable{

    private int id;
    private String name;
    private int done; //0 == false (or not done) 1 == true (or done)

    public Task(int id, String name, int done) {

        this.id = id;
        this.name = name;
        this.done = done;
    }

    public int getId() {return id;}
    public String getName() {return name;}
    public int getDone() {return done;}
}
