package com.example.stephen.taskmaster;

/**
 * Created by Stephen on 10/20/2017.
 */
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import android.widget.EditText;


/**
 * Created by resortrat on 11/1/15.
 */
public class TaskRunner extends Activity {

    public final static String toTransfer = "com.example.resortrat.ndsucampusmap._lat";


    private TaskHandler dbTaskHandler = null;
    private TaskAdapter adapter = null;
    private Cursor ourCursor = null;
    private ListView myListView;


    int thisId;
    Task thisTask;


    private static final int STOPSPLASH = 0;
    //time in milliseconds
    private static final long SPLASHTIME = 3000;

    private ImageView splash;

    //handler for splash screen
    private Handler splashHandler = new Handler() {
        /* (non-Javadoc)
         * @see android.os.Handler#handleMessage(android.os.Message)
         */
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case STOPSPLASH:
                    //remove SplashScreen from view
                    splash.setVisibility(View.GONE);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    /*Function used for the opening of the functions of the application. This one does:
    1.Runs the splashHandles
    2.Initalizes the list view
    3.Opens the database
    4.Loads the data into a cursor
    5.Displays the data from the cursor into the listview
    6.If an item is clicked it loads a new instance of "MapsActivity" and sends the data of
        the item clicked on to the created activity
     */
    public void onCreate(Bundle savedInstanceState) {

        try {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            splash = (ImageView) findViewById(R.drawable.splashscreen);
            Message msg = new Message();
            msg.what = STOPSPLASH;
            splashHandler.sendMessageDelayed(msg, SPLASHTIME);

            //this is our ListView element, obtained by id from our XML layout
            myListView = (ListView) findViewById(R.id.row);


            //create our database Handler
            dbTaskHandler = new TaskHandler(this);
            //we call the create right after initializing the helper, just in case
            //they have never the app before
            dbTaskHandler.createDatabase();

            //open the database. Our helper now has a SQLiteDatabase database object
            dbTaskHandler.openDataBase();
            //get our cursor. A cursor is a pointer to a dataset, in this case
            //a set of results from a database query
            ourCursor = dbTaskHandler.getCursor(0, null);
            //tell android to start managing the cursor,
            startManagingCursor(ourCursor);
            //create our adapter
            adapter = new TaskAdapter(ourCursor);
            //set the adapter
            myListView.setAdapter(adapter);


            //onClick
            myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @TargetApi(Build.VERSION_CODES.M)
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //something here takes the task and converts it to a completed task
                    Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
                    thisId = (int) id;
                    thisTask = dbTaskHandler.getData(thisId);

                    myIntent.putExtra(toTransfer, String.valueOf(id));
                    myIntent.putExtra("Key", thisTask);
                    startActivity(myIntent);


                }
            });


        } catch (Exception e) {
            Log.e("Error", "Error In Code: " + e.toString());
            e.printStackTrace();

        }
    }


    //takes the data using "TaskHolder" and converts into language readable by JAVA
    //which can be used in the view
    class TaskAdapter extends CursorAdapter {
        TaskAdapter(Cursor c) {
            super(TaskRunner.this, c);
        }

        @Override
        public void bindView(View row, Context ctxt, Cursor c) {
            TaskHolder holder = (TaskHolder) row.getTag();
            holder.populateFrom(c, dbTaskHandler);
        }

        @Override
        public View newView(Context ctxt, Cursor c, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            TaskHolder holder = new TaskHolder(row);
            row.setTag(holder);
            return (row);
        }

    }

    //takes the "_itemName" from the database and sets as a readable text that can be used
    //in the listview
    static class TaskHolder {
        private TextView name = null;

        TaskHolder(View row) {
            name = (TextView) row.findViewById(R.layout.tasktext);
        }

        void populateFrom(Cursor c, TaskHandler r) {
            name.setText(r.getName(c));
        }
    }

}
